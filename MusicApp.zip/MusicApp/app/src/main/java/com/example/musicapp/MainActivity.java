package com.example.musicapp;

import android.content.Intent;
import android.media.MediaPlayer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TextView randb = (TextView) findViewById(R.id.RB);
        randb.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Intent rbIntent = new Intent(MainActivity.this, RandB.class);
                startActivity(rbIntent);
            }

        });
        TextView rap = (TextView) findViewById(R.id.RAP);
        rap.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Intent rapIntent = new Intent(MainActivity.this, Rap.class);
                startActivity(rapIntent);
            }

        });
        TextView edm = (TextView) findViewById(R.id.EDM);
        edm.setOnClickListener((new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent edmIntent = new Intent(MainActivity.this, EDM.class);
                startActivity(edmIntent);
            }
        }));

    }

}
