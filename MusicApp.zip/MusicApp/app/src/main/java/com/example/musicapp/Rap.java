package com.example.musicapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;

import java.util.ArrayList;

public class Rap extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rap);
        ArrayList<Song> songlist = new ArrayList<>();
        songlist.add(new Song("Eminem","Rainy Days"));
        songlist.add(new Song("Eminem","Lose Yourself"));
        songlist.add(new Song("Eminem","Fall"));

        SongAdapter itemsAdapter = new SongAdapter(this, songlist);
        ListView listView = (ListView) findViewById(R.id.rap_list);
        listView.setAdapter(itemsAdapter);

        Button btn = (Button) findViewById(R.id.btn_add);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent startIntent = new Intent(getBaseContext(), MainActivity.class);
                startIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(startIntent);
            }
        });

    }
}
