package com.example.musicapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Adapter;
import android.widget.Button;
import android.widget.ListView;
import android.support.v4.app.Fragment;

import java.util.ArrayList;

public class EDM extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edm);
        ArrayList<Song> songlist = new ArrayList<>();
        songlist.add(new Song("Neovaii", "Take It Back"));
        songlist.add(new Song("Tycho", "Easy"));
        songlist.add(new Song("Neovaii", "I Remember"));

        SongAdapter itemsAdapter = new SongAdapter(this, songlist);
        ListView listView = (ListView) findViewById(R.id.edmList);
        listView.setAdapter(itemsAdapter);

        Button btn = (Button) findViewById(R.id.btn_add);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent startIntent = new Intent(getBaseContext(), MainActivity.class);
                startIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(startIntent);
            }
        });

    }

}
